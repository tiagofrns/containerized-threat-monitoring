# Attack-defense tree: temperature service

Updated: 18 November 2026. This model separates hypotheses, historical workload
observations and verified defense behavior.

## Scope within the selected project plan

This tree covers scenario 1, availability/DoS. The adopted project also includes
[DNS hijacking](../docs/scenarios/02-dns-hijacking/README.md) and
[spam classification/quarantine](../docs/scenarios/03-spam/README.md). Their
scenario-specific threat models and trees are pending. This tree does not
claim to model all three cases. Current case-1 results are maintained in
[the scenario page](../docs/scenarios/01-dos/README.md).

## Attacker model and vocabulary

The remote attacker can reach exposed application NodePorts in the isolated lab.
They have no SSH, Incus administration, Kubernetes credentials or direct SQLite access.
The legitimate client is a separate Pod. Infrastructure failure is a separate scenario.

The root is the goal. OR means alternative branches; AND means all child conditions
are required. A leaf has not been decomposed further. Defense nodes counter specific
actions or necessary conditions.

## Model

```text
A0: Degrade temperature service for legitimate users [OR]
|
+-- A1: Overload POST /ingest [AND; not tested here]
|   +-- A11: Reach the ingestion endpoint
|   +-- A12: Submit enough work to exceed effective capacity
|   +-- A13: Admission controls do not constrain that work
|   Defense D1: Ingestion admission/rate controls [proposed, not implemented]
|
+-- A2: Degrade GET /average through excessive query traffic [AND]
    +-- A21: Reach the analytics endpoint
    +-- A22: Create sufficient work or contention to affect legitimate queries
    +-- A23: Effective request admission does not constrain the source
    Defense D2: Five requests/second per observed source IP [implemented]
    Defense D3: Wazuh-triggered temporary cache reduces repeated dependency work [implemented]
```

## Evidence and its limits

Historical user-run workload: evidence/attacker-test-01/result.txt records
200 workers, a configured 200 requests/second and 30 seconds. It reports
6,000 outcomes: 5,829 HTTP 200 and 171 timeouts. Those are generator outcomes.
The user reported approximately tenfold legitimate-client latency, but exact
time-series values from that event were not retained in this file.

Logs showed generator requests under observed address 10.42.0.0, distinct from
the client and exporter Pods. This supports separating sources for this lab.
It does not prove that 10.42.0.0 is the attacker's original address.

D2 is implemented in apps/analytics.py using Flask-Limiter and moving-window storage
in memory. The current manifest enables it and deploys ssle-analytics:protective-cache-v1.
The original limiter tests and earlier deployed checks confirm enforcement,
source separation and recovery. They do not establish performance protection
under the historical workload. No new overload run was executed here.

A22 remains a causal hypothesis until resource, client and log observations under
comparable workload distinguish application pressure from VM/generator contention.

## Observations and response trade-offs

Observe legitimate-client latency/errors, application probes, analytics response
statuses, downstream call rate, container CPU/memory and correlated logs.

Per-source limits can reject legitimate bursts and group users behind the same
translated address. A distributed workload can use several budgets. Memory state
is local to one process, resets on restart and is not coordinated across replicas.
Receiving and rejecting traffic still consumes resources.

Blocklisting can suppress a known source but can block unrelated shared-address
users and does not address changing origins. It was discussed, not implemented.
Global admission control or a shared limiter backend are future options, not
features of this deployment.

## Monitoring failure is a different risk

A dead publisher can leave an apparently healthy cached Pushgateway value.
The implementation adds an observation timestamp, a freshness alert, bounded
publication retries and explicit group cleanup. The live comparison verified
staleness detection and recovery. This is a monitoring-reliability experiment,
not another demonstrated project threat.

## Remaining evaluation

Record comparable legitimate-client metrics and service resources with and
without D2 before claiming a measured mitigation improvement.
This tree covers Guide 3 and does not replace three distinct Project 1 scenarios.

Method: https://satoss.uni.lu/projects/atrees/

## D3: temporary protective caching

Rule 100121 triggers a scoped local response that activates a 60-second lease.
Analytics reuses validated results for five seconds and bounds a labelled
failure fallback to ten seconds. The application enforces expiry independently
of Wazuh deletion. This reduces dependency work, while D2 continues controlling
admission. It does not block the shared CNI source or mitigate bandwidth exhaustion.

The new functional run verified actual activation and reversal, ten cached
replies among twelve protected manual reads, explicit freshness and indexed
audit events. Thirty-six isolated regressions passed. Full evidence and limits
are in the [scenario page](../docs/scenarios/01-dos/README.md). D3 is per process
and node; comparable-load efficacy and distributed coordination remain unevaluated.
